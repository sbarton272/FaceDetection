function [model] = load_model()
    load('baseline_model.mat');
end